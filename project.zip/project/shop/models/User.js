const mongoose = require('mongoose');

// Define the User Schema
const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
        unique: true, // Make sure the email is unique
    },
    gender: {
        type: String,
        enum: ['male', 'female', 'other'],
        required: true,
    },
    phoneNo: {
        type: String,
        required: true,
        unique: true,
    },
    password: {
        type: String,
        required: true,
    },
    isAdmin: {
        type: Boolean,
        default: false, // Default is false (regular user)
    }
});

// Create the User model
const User = mongoose.model('User', userSchema);

module.exports = User;
