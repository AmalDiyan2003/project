const mongoose = require('mongoose');

var schema = mongoose.Schema({
    name: String, 
    price: Number,
    quantity: Number,
    category: String,
    image: [String],
    description: String,
});
var shopModel = mongoose.model("Product", schema); 
module.exports = shopModel;