const express = require('express');
const mongoose = require('mongoose');
const User = require('./models/User'); // Import User model
const Product = require('./models/product'); // Import Product model

const app = express();
app.use(express.json()); // Middleware to parse JSON bodies
const cors = require('cors');
app.use(cors());

// ✅ Connect to MongoDB
require('./connection');

// 🔹 Middleware to check if the user is an admin
const isAdmin = async (req, res, next) => {
    try {
        const phoneNo = req.headers.phoneno; // Get phone number from headers
        if (!phoneNo) {
            return res.status(403).send({ error: " Phone number required in headers" });
        }

        const user = await User.findOne({ phoneNo });
        if (!user || !user.isAdmin) {
            return res.status(403).send({ error: " Access denied. Admins only" });
        }

        req.user = user; // Attach user to request
        next();
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
};

// 🔹 USER ROUTES

// ✅ Register a new user (without password encryption)
// ✅ Register a new user (without password encryption)
app.post('/register', async (req, res) => {
    const { name, email, password, gender, phoneNo } = req.body;

    try {
        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'Email already in use.' });
        }

        // Create a new user without the isAdmin field
        const newUser = new User({
            name,
            email,
            password,
            gender,
            phoneNo,
            isAdmin: false, // Default value as false
        });

        await newUser.save();

        res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error registering user', error: error.message });
    }
});


// ✅ Get all users
app.get('/users', async (req, res) => {
    try {
        const users = await User.find();
        res.status(200).send(users);
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
});

// ✅ Update user by ID
app.put('/users/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const updatedUser = await User.findByIdAndUpdate(id, req.body, { new: true, runValidators: true });

        if (!updatedUser) {
            return res.status(404).send({ error: 'User not found' });
        }

        res.status(200).send(updatedUser);
    } catch (error) {
        res.status(400).send({ error: error.message });
    }
});

// ✅ Delete user by ID
app.delete('/users/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const deletedUser = await User.findByIdAndDelete(id);

        if (!deletedUser) {
            return res.status(404).send({ error: ' User not found' });
        }

        res.status(200).send({ message: ' User deleted successfully' });
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
});

// 🔹 PRODUCT ROUTES

// ✅ Anyone Can Add Products (Removed Admin check)
app.post('/products', async (req, res) => {
    try {
        const product = new Product(req.body);
        await product.save();
        res.status(201).send(product);
    } catch (error) {
        res.status(400).send({ error: error.message });
    }
});

// ✅ Anyone Can View Products
app.get('/products', async (req, res) => {
    try {
        const products = await Product.find();
        res.status(200).send(products);
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
});

const jwt = require('jsonwebtoken'); // Add this at the top

app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ message: 'Invalid email or password' });
        }

        // Direct password comparison (no hashing in this case)
        if (password !== user.password) {
            return res.status(400).json({ message: 'Invalid email or password' });
        }

        // Generate JWT token
        const token = jwt.sign(
            { userId: user._id, isAdmin: user.isAdmin },
            'secret-key',  // Replace with your actual secret key
            { expiresIn: '1h' }
        );

        res.status(200).json({ message: 'Login successful', token });
    } catch (error) {
        res.status(500).json({ message: 'Error logging in', error: error.message });
    }
});



app.get("/profile", async (req, res) => {
    const token = req.headers.authorization?.split(" ")[1];
  
    if (!token) {
      return res.status(401).json({ message: "Authentication required" });
    }
  
    try {
    // const decoded = jwt.verify(token, "your-secret-key");
      const user = await User.findById(decoded.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
  
      res.status(200).json(user);
    } catch (error) {
      res.status(401).json({ message: "Invalid or expired token" });
    }
  });
  
// ✅ Only Admins Can Update Products
app.put('/products/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const product = await Product.findByIdAndUpdate(id, req.body, { new: true, runValidators: true });

        if (!product) {
            return res.status(404).send({ error: 'Product not found' });
        }

        res.status(200).send(product);
    } catch (error) {
        res.status(400).send({ error: error.message });
    }
});

// ✅ Only Admins Can Delete Products
app.delete('/products/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const product = await Product.findByIdAndDelete(id);

        if (!product) {
            return res.status(404).send({ error: 'Product not found' });
        }

        res.status(200).send({ message: 'Product deleted successfully' });
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
});

// 🔹 Start the Server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
