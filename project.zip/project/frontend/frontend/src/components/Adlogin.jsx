import { Box, Button, TextField, Typography } from "@mui/material";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const Adlogin = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();
    
        console.log('email:', email);  // Debugging
    
        // Check if email and password match the specified ones
        if (email === "group1@gmail.com" && password === "123456789") {
            try {
                const resp = await axios.post("http://localhost:3000/login", { email, password });
                
                // Store the token in localStorage on successful login
                localStorage.setItem("token", resp.data.token);
        
                // Redirect to profile page
                navigate("/admin");
            } catch (error) {
                console.log(error.response);  // Debugging error response
                setError("Invalid email or password.");
            }
        } else {
            setError("Invalid email or password.");
        }
    }

    return (
        <div>
            <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100vh", width: "100vw", backgroundColor: "#f4f4f4" }}>
                <Box sx={{ display: "flex", flexDirection: "column", maxWidth: 400, width: "90%", padding: 4, boxShadow: 5, borderRadius: 2, backgroundColor: "white", gap: 2 }}>
                    <Typography variant="h5" color="black" sx={{ textAlign: "center", marginBottom: 2 }}>
                        Login
                    </Typography>
                    {error && <Typography color="error" sx={{ textAlign: "center" }}>{error}</Typography>}
                    <TextField id="email" label="Email ID" variant="outlined" fullWidth value={email} onChange={(e) => setEmail(e.target.value)} />
                    <TextField id="password" label="Password" variant="outlined" type="password" fullWidth value={password} onChange={(e) => setPassword(e.target.value)} />
                    <Box sx={{ display: "flex", justifyContent: "center" }}>
                        <Button variant="contained" fullWidth onClick={handleLogin}>Login</Button>
                    </Box>
                </Box>
            </Box>
        </div>
    );
}

export default Adlogin;
