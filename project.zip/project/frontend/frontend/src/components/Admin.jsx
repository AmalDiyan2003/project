import React, { useState, useEffect } from 'react';
import { TextField, Button, Grid, Container, Typography } from '@mui/material';
import axios from 'axios';
import { blueGrey, lightBlue } from '@mui/material/colors';

export default function Admin() {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    quantity: '',
    category: '',
    image: '',
  });

  const [products, setProducts] = useState([]);
  const [error, setError] = useState(null);
  const [editingProduct, setEditingProduct] = useState(null); // Track product to be edited

  // Fetch products when the component mounts
  useEffect(() => {
    axios.get('http://localhost:3000/products')
      .then(response => setProducts(response.data))
      .catch(error => setError('Error fetching products.'));
  }, []);

  // Handle input changes for form data
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };

  // Handle form submission to add or update a product
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (editingProduct) {
        // Update product
        const response = await axios.put(
          `http://localhost:3000/products/${editingProduct._id}`, // Update by product ID
          formData
        );
        setProducts(products.map(product => product._id === editingProduct._id ? response.data : product));
      } else {
        // Add new product
        const response = await axios.post(
          'http://localhost:3000/products', // No admin authentication
          formData
        );
        setProducts([...products, response.data]);
      }
      setFormData({ name: '', description: '', price: '', quantity: '', category: '', image: '' });
      setEditingProduct(null); // Clear editing state
    } catch (error) {
      setError('Error adding or updating product.');
    }
  };

  // Handle editing a product (fill the form with product data)
  const handleEdit = (product) => {
    setFormData({
      name: product.name,
      description: product.description,
      price: product.price,
      quantity: product.quantity,
      category: product.category,
      image: product.image.join(', '), // Handle image as a comma-separated string
    });
    setEditingProduct(product);
  };

  // Handle deleting a product
  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:3000/products/${id}`);
      setProducts(products.filter(product => product._id !== id));
    } catch (error) {
      setError('Error deleting product.');
    }
  };

  return (
    <Container>
      <br />
      <Typography variant="h4" color={blueGrey[700]}>
        {editingProduct ? 'Edit Product' : 'Add Product'}
      </Typography>

      {/* Error message */}
      {error && <Typography color="error">{error}</Typography>}

      <form onSubmit={handleSubmit}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <TextField
              name="name"
              label="Product Name"
              value={formData.name}
              onChange={handleChange}
              fullWidth
              required
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              name="description"
              label="Description"
              value={formData.description}
              onChange={handleChange}
              fullWidth
              required
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              name="price"
              label="Price"
              value={formData.price}
              onChange={handleChange}
              type="number"
              fullWidth
              required
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              name="quantity"
              label="Quantity"
              value={formData.quantity}
              onChange={handleChange}
              type="number"
              fullWidth
              required
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              name="category"
              label="Category"
              value={formData.category}
              onChange={handleChange}
              fullWidth
              required
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              name="image"
              label="Image URL (comma separated)"
              value={formData.image}
              onChange={handleChange}
              fullWidth
            />
          </Grid>
          <Grid item xs={12}>
            <Button type="submit" variant="contained" color="primary">
              {editingProduct ? 'Update Product' : 'Add Product'}
            </Button>
          </Grid>
        </Grid>
      </form>

      <Typography variant="h5" color={lightBlue[500]} sx={{ mt: 4 }}>
        Current Products
      </Typography>

      <Grid container spacing={2}>
        {products.map((product) => (
          <Grid item xs={12} sm={6} md={4} key={product._id}>
            <div>
              <Typography variant="h6">{product.name}</Typography>
              <Typography>{product.description}</Typography>
              <Typography>Price: ${product.price}</Typography>
              <Typography>Quantity: {product.quantity}</Typography>
              <Typography>Category: {product.category}</Typography>
              {product.image && product.image.length > 0 && (
                <img src={product.image[0]} alt={product.name} width="100" />
              )}
              <div>
                <Button
                  variant="outlined"
                  color="primary"
                  onClick={() => handleEdit(product)}
                  sx={{ mt: 1, mr: 1 }}
                >
                  Edit
                </Button>
                <Button
                  variant="outlined"
                  color="error"
                  onClick={() => handleDelete(product._id)}
                  sx={{ mt: 1 }}
                >
                  Delete
                </Button>
              </div>
            </div>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}
