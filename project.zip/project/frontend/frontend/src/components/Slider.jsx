import { Carousel } from 'antd';
import { Link } from 'react-router-dom';


const Slider = () => {
    return (
        <Carousel autoplay autoplaySpeed={3000}>
        <div> 
        
        <img src="https://www.smartcellular.ie/media/magiccart/magicslider/s/c/sc_ire3.gif" height={600} width={1500}></img>
        
        </div>
        <div> 
            
            

        <img src="https://cdn.shopify.com/s/files/1/0773/8628/5348/files/Blue_Pink_Modern_Special_Offer_Sale_Banner.png?v=1735216700" height={600} width={1500}></img>
        </div>
        <div>
        
        <img src="https://t4.ftcdn.net/jpg/05/07/79/69/360_F_507796978_MwplqZOKyeIN7fACIrLygrgnOjDmYRUL.jpg" height={600} width={1500}></img>
        </div>
        <div><br />
        <img src="https://images.fonearena.com/blog/wp-content/uploads/2024/11/Amazon-Mega-Smartwatch-Days-sale-November-2024.jpg" height={600} width={1500}></img>
        </div>
      </Carousel>
    );
  };
  
  
  const contentStyle = {
    textAlign: 'center',
    height: '200px',
    lineHeight: '200px',
    background: '#364d79',
  };
  
  
  export default Slider;