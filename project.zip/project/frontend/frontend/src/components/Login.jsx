import { Box, Button, TextField, Typography } from "@mui/material";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();

    if (!email || !password) {
      setError("Both fields are required.");
      return;
    }

    try {
      const response = await axios.post("http://localhost:3000/login", { email, password });

      // Store the token in localStorage on successful login
      localStorage.setItem("token", response.data.token);

      // Redirect to home page
      navigate("/home");
    } catch (error) {
      console.error(error.response); // Debugging error response
      setError("Invalid email or password.");
    }
  };

  return (
    <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100vh", width: "100vw", backgroundColor: "#f4f4f4" }}>
      <Box sx={{ display: "flex", flexDirection: "column", maxWidth: 400, width: "90%", padding: 4, boxShadow: 5, borderRadius: 2, backgroundColor: "white", gap: 2 }}>
        <Typography variant="h5" color="black" sx={{ textAlign: "center", marginBottom: 2 }}>
          Login
        </Typography>

        {error && <Typography color="error" sx={{ textAlign: "center" }}>{error}</Typography>}

        <TextField
          id="email"
          label="Email ID"
          variant="outlined"
          fullWidth
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          sx={{ marginBottom: 2 }}
        />
        <TextField
          id="password"
          label="Password"
          variant="outlined"
          type="password"
          fullWidth
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          sx={{ marginBottom: 2 }}
        />

        <Box sx={{ display: "flex", justifyContent: "center" }}>
          <Button variant="contained" fullWidth onClick={handleLogin}>Login</Button>
        </Box>

        <Box sx={{ display: "flex", justifyContent: "center", marginTop: 2 }}>
          <Link to="/register" style={{ textDecoration: "none", width: "100%" }}>
            <Button variant="contained" fullWidth>
              Sign up
            </Button>
          </Link>
        </Box>
      </Box>
    </Box>
  );
};

export default Login;
