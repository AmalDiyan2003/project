import React, { useState, useEffect } from "react";
import { useLocation, Link } from "react-router-dom";
import { Box, Typography, Button, Card, CardContent, CardMedia } from "@mui/material";

const Cart = () => {
  const location = useLocation();
  const [product, setProduct] = useState(null);

  useEffect(() => {
    // Check if product is passed via location state
    if (location.state?.product) {
      setProduct(location.state.product); // Set product state
      localStorage.setItem('product', JSON.stringify(location.state.product)); // Store product in localStorage
    } else {
      // If no product is passed in location state, check localStorage
      const storedProduct = localStorage.getItem('product');
      if (storedProduct) {
        setProduct(JSON.parse(storedProduct)); // Retrieve product from localStorage
      }
    }
  }, [location]);

  const handleProceedToCheckout = () => {
    if (product) {
      localStorage.setItem('product', JSON.stringify(product)); // Store product in localStorage when proceeding to checkout
    }
  };

  const handleRemoveFromCart = () => {
    localStorage.removeItem('product'); // Remove product from localStorage
    setProduct(null); // Clear product from state
  };

  // If no product is available in the cart (either from location or localStorage)
  if (!product) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "100vh",
          backgroundColor: "#f4f4f4",
        }}
      >
        <Typography variant="h6">No product selected. Please go back and choose a product.</Typography>
      </Box>
    );
  }

  return (
    <Box
      sx={{
        height: "100vh",
        width: "100vw",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#f4f4f4",
        padding: 4,
      }}
    >
      <Typography variant="h5" color="black" sx={{ textAlign: "center", marginBottom: 2 }}>
        Cart
      </Typography>

      <Card sx={{ maxWidth: 345, marginBottom: 2 }}>
        <CardMedia sx={{ height: 180 }} image={product.image} title={product.title} />
        <CardContent>
          <Typography gutterBottom variant="h6" noWrap>
            {product.title}
          </Typography>
          <Typography variant="subtitle2" color="text.secondary">
            {product.category}
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ height: 50, overflow: "hidden", textOverflow: "ellipsis" }}>
            {product.description}
          </Typography>
          <Typography variant="h6">₹{product.price}</Typography>
        </CardContent>
      </Card>

      {/* If order is completed */}
      {location.state?.orderCompleted && (
        <Typography variant="h6" color="primary" sx={{ marginBottom: 2 }}>
          Order Completed! Thank you for your purchase.
        </Typography>
      )}

      {/* If not yet completed, show Proceed to Checkout */}
      {!location.state?.orderCompleted && (
        <Box sx={{ display: "flex", justifyContent: "center", width: "100%" }}>
          <Link to="/payment" style={{ textDecoration: "none" }}>
            <Button
              variant="contained"
              size="large"
              sx={{ width: "auto", marginRight: 2 }}
              onClick={handleProceedToCheckout}
            >
              Proceed to Checkout
            </Button>
          </Link>
        </Box>
      )}

      {/* Remove from Cart button */}
      <Button
        variant="outlined"
        color="error"
        size="large"
        sx={{ width: "auto" }}
        onClick={handleRemoveFromCart} // Remove product from localStorage and state
      >
        Remove from Cart
      </Button>
    </Box>
  );
};

export default Cart;
