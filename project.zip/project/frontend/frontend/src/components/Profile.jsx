import { Box, Typography, CircularProgress } from "@mui/material";
import React, { useEffect, useState } from "react";
import axios from "axios";

const Profile = () => {
  const [user, setUser] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUserProfile = async () => {
      const token = localStorage.getItem("token");

      if (!token) {
        setError("You need to login first.");
        setLoading(false);
        return;
      }

      try {
        const response = await axios.get("http://localhost:3000/profile", {
          headers: {
            Authorization: `Bearer ${token}`, // Include token in Authorization header
          },
        });
        setUser(response.data);
        setLoading(false);
      } catch (error) {
        setError("Failed to fetch user data.");
        setLoading(false);
      }
    };

    fetchUserProfile();
  }, []);

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ padding: 2 }}>
      {error && <Typography color="error">{error}</Typography>}
      {user && (
        <Box>
          <Typography variant="h6">Welcome, {user.name}!</Typography>
          <Typography>Email: {user.email}</Typography>
          <Typography>Phone: {user.phoneNo}</Typography>
        </Box>
      )}
    </Box>
  );
};

export default Profile;
