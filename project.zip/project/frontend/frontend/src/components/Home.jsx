import React, { useState, useEffect } from "react";
import { Card, CardActions, CardContent, CardMedia, Button, Typography, Grid, Box, CircularProgress, Alert } from "@mui/material";
import axios from "axios";
import { Link } from "react-router-dom";
import Slider from './Slider'; // Slider component

const Home = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Replace the URL with your backend's API endpoint
    axios
      .get("http://localhost:3000/products") // Your backend URL
      .then((res) => {
        setData(res.data); // Store product data in the state
        setLoading(false);
      })
      .catch((error) => {
        setError("Error fetching data.");
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
        <Alert severity="error">{error}</Alert>
      </Box>
    );
  }

  return (
    <div>
      {/* Add the Slider component here */}
      <Slider />

      {/* Display products */}
      <Box
        sx={{
          minHeight: "100vh",
          width: "100vw",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: 4,
          backgroundColor: "#f4f4f4",
        }}
      >
        <Grid container spacing={2} justifyContent="center">
          {data.map((val) => (
            <Grid item xs={12} sm={6} md={4} lg={3} key={val._id}> {/* Use _id as key */}
              <Card sx={{ maxWidth: "100%", height: "100%", display: "flex", flexDirection: "column" }}>
                <CardMedia sx={{ height: 180 }} image={val.image[0]} title={val.title} /> {/* Assuming image is an array */}
                <CardContent sx={{ flexGrow: 1 }}>
                  <Typography gutterBottom variant="h6" noWrap>
                    {val.name}
                  </Typography>
                  <Typography variant="subtitle2" color="text.secondary">
                    {val.category}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ height: 50, overflow: "hidden", textOverflow: "ellipsis" }}>
                    {val.description}
                  </Typography>
                  <Typography variant="h6">₹{val.price}</Typography>
                </CardContent>
                <CardActions sx={{ justifyContent: "center" }}>
                  <Link to="/cart" state={{ product: val }} style={{ textDecoration: "none" }}>
                    <Button variant="contained">Buy</Button>
                  </Link>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Box>
    </div>
  );
};

export default Home;
