import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './components/Home';
import Login from './components/Login';
import Registration from './components/Registration';
import Cart from './components/Cart';
import Payment from './components/Payment';
import Profile from './components/Profile';
import Admin from './components/Admin'; 
import Slider from './components/Slider';
import Adlogin from './components/Adlogin';

function App() {
  return (
    <div className="app-container"> {/* Apply styles using CSS */}
      <Navbar />
      <Routes>
        {/* <Route path="/" element={<Home />} /> */}
        <Route path="/" element={<Login />} />
        <Route path="/home" element={<Home />} />
        <Route path="/register" element={<Registration />} />
        <Route path="/adlogin" element={<Adlogin />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/payment" element={<Payment />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/admin" element={<Admin />} /> 
      </Routes>
    </div>
  );
}

export default App;
